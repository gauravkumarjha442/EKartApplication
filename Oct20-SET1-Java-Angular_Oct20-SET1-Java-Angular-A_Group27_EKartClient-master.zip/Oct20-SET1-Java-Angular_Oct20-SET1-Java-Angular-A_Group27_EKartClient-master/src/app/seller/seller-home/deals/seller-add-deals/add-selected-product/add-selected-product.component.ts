import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { SellerAddDealsService } from '../seller-add-deals.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductOnDeals } from 'src/app/shared/models/productOnDeals';

@Component({
  selector: 'add-selected-product',
  templateUrl: './add-selected-product.component.html',

})
export class AddSelectedProductComponent implements OnInit {

  addProductToDealForm:FormGroup;
  successMessage:String=null;
  errorMessage:String=null;
  tryAgain:boolean=false;

  @Input()
  selectedProduct: Product;
  constructor(private addDealsService: SellerAddDealsService,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.addProductToDealForm=this.formBuilder.group({
      productid:[this.selectedProduct.productId,[Validators.required]],
      startDateTime:["",[Validators.required]],
      endDateTime:["",[Validators.required]],
      dealDiscount:[this.selectedProduct.discount,[Validators.required,Validators.pattern('[0-9]{1,2}')]]
    })
  }

  addToDeals() {
    let productOnDeals:ProductOnDeals=new ProductOnDeals();
    
    productOnDeals.product=this.selectedProduct;
    productOnDeals.seller=JSON.parse(sessionStorage.getItem("seller"));
    productOnDeals.dealDiscount=this.addProductToDealForm.get('dealDiscount').value;
    productOnDeals.startDateTime=this.addProductToDealForm.get('startDateTime').value;
    productOnDeals.endDateTime=this.addProductToDealForm.get('endDateTime').value;

    this.addDealsService.addProductToDeals(productOnDeals).subscribe(
      (response)=>{
        this.successMessage=response;
        this.errorMessage=null;
        this.tryAgain=false;
        
      },
      (response)=>{
        response.error=JSON.parse(response.error)
        this.errorMessage=response.error.message;
        this.tryAgain=true;
      }
    )
  }

}