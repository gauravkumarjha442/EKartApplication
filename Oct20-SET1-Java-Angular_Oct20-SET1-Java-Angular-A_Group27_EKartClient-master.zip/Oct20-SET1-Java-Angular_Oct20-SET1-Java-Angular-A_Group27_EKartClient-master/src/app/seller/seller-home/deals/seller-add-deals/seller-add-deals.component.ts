import { Component, OnInit } from '@angular/core';
import { SellerAddDealsService } from './seller-add-deals.service';
import { Seller } from 'src/app/shared/models/seller';
import { Product } from 'src/app/shared/models/product';

@Component({
  selector: 'app-seller-add-deals',
  templateUrl: './seller-add-deals.component.html',
  styleUrls: ['./seller-add-deals.component.css']
})
export class SellerAddDealsComponent implements OnInit {

  constructor(private addDealsService: SellerAddDealsService) { }
  productNotOnDeals: Product[];
  errorMessage: string;
  successMessage: string;
  isProductSelected: boolean = false;
  seller: Seller;
  selectedProduct: Product;
  ngOnInit() {
    this.seller = this.getSellerFromSession();
    this.errorMessage = null;
    this.productNotOnDeals = null;
    this.successMessage = null;
    this.getAllProductNotOnDeals();

  }
  getAllProductNotOnDeals() {
    this.addDealsService.getProductNotOnDeals(this.seller.emailId).subscribe(
      (result) => {

        this.productNotOnDeals = result
          
      }, (result) => {
        this.errorMessage = result.error.errorMessage
          

      })
  }
  

  setSelectedProduct(product: Product) {
    this.isProductSelected = true;
    this.successMessage = null;
    this.selectedProduct = product;
  }

  unsetSelectedProduct() {
    this.isProductSelected = false;
    this.selectedProduct = null;
    this.getAllProductNotOnDeals();
  }





  getSellerFromSession() {
    return JSON.parse(sessionStorage.getItem("seller"))
  }

}