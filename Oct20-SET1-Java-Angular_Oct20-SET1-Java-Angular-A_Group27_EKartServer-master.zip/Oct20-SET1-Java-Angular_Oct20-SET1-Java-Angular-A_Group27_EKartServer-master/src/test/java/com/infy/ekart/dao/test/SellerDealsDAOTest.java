package com.infy.ekart.dao.test;

import java.time.LocalDate;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dao.SellerDealsDAO;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.model.Seller;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@Transactional
@Rollback(true)
public class SellerDealsDAOTest {
	
	@Autowired
	private SellerDealsDAO sellerDealsDAO;
	
	@Test
	public void addProductOnDeals() {
		ProductOnDeals productOnDeals=new ProductOnDeals();
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		seller.setName("Jack");
		seller.setPassword("29409af3b6b7ca673ffd6b4407741e095c741aa28d2c55c65449e460c051c01d");
		seller.setPhoneNumber("7614162396");
		seller.setAddress("Ist Main, Building No.3, Park Square, Salem, US");
		
		
		Product product=new Product();
		product.setProductId(1000);
		product.setName("Bot E5s Plus");
		product.setDescription("Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setCategory("Electronics - Mobile");
		product.setBrand("Motobot");
		product.setPrice(16000.0);
		product.setDiscount(5.0);
		product.setQuantity(150);
		
		productOnDeals.setDealDiscount(15.00);
		productOnDeals.setSeller(seller);
		productOnDeals.setProduct(product);
		
		LocalDate sdate=LocalDate.now().plusDays(1);
		productOnDeals.setStartDateTime(sdate.atStartOfDay());
		
		LocalDate edate=LocalDate.now().plusDays(2);
		productOnDeals.setEndDateTime(edate.atStartOfDay());
		
		sellerDealsDAO.addProductOnDeals(productOnDeals);
		Assert.assertTrue(true);
			
	}
	
	@Test
	public void getProductOnDeals() {
		Assert.assertNotNull(sellerDealsDAO.getProductOnDeals("jack@infosys.com"));
	}
	
	@Test
	public void removeProductOnDeals() {
		Assert.assertNotNull(sellerDealsDAO.removeProductOnDeals(501001));
		
	}
	
	
	@Test
	public void getProductNotOnDeals() {
		Assert.assertNotNull(sellerDealsDAO.getProductNotOnDeals("jack@infosys.com"));
		
	}
}