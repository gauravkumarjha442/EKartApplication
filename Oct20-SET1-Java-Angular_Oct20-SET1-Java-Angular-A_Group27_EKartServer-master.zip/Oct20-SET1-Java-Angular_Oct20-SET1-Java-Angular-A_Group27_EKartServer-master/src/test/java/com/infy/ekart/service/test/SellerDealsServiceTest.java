package com.infy.ekart.service.test;

import static org.mockito.Mockito.when;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.infy.ekart.dao.SellerDealsDAO;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.model.Seller;
import com.infy.ekart.service.SellerDealsService;
import com.infy.ekart.service.SellerDealsServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SellerDealsServiceTest {
	
	@Mock
	private  SellerDealsDAO sellerDealsDAO;
	
	@InjectMocks
	private SellerDealsService sellerDealsService=new SellerDealsServiceImpl();
	
	@Rule
	public ExpectedException expectedException =ExpectedException.none();
	
	@Test
	public void addProductOnDealsValid()throws Exception{
		ProductOnDeals productOnDeals=new ProductOnDeals();
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		seller.setName("Jack");
		seller.setPassword("29409af3b6b7ca673ffd6b4407741e095c741aa28d2c55c65449e460c051c01d");
		seller.setPhoneNumber("7614162396");
		seller.setAddress("Ist Main, Building No.3, Park Square, Salem, US");
		
		
		Product product=new Product();
		product.setProductId(1000);
		product.setName("Bot E5s Plus");
		product.setDescription("Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setCategory("Electronics - Mobile");
		product.setBrand("Motobot");
		product.setPrice(16000.0);
		product.setDiscount(5.0);
		product.setQuantity(150);
		
		productOnDeals.setDealDiscount(15.00);
		productOnDeals.setSeller(seller);
		productOnDeals.setProduct(product);
		
		LocalDate sdate=LocalDate.now().plusDays(1);
		productOnDeals.setStartDateTime(sdate.atStartOfDay());
		
		LocalDate edate=LocalDate.now().plusDays(2);
		productOnDeals.setEndDateTime(edate.atStartOfDay().minusSeconds(1));
		
		Mockito.when(sellerDealsDAO.addProductOnDeals(productOnDeals)).thenReturn(501001);
		sellerDealsService.addProductOnDeals(productOnDeals);
	}
	
	@Test
	public void getProductOnDealsValid()throws Exception{
		List<ProductOnDeals> list = new ArrayList<ProductOnDeals>();
		ProductOnDeals pd = null;
		list.add(pd);
		when(sellerDealsDAO.getProductOnDeals("jack@infosys.com")).thenReturn(list);
		List<ProductOnDeals> returned=sellerDealsService.getProductOnDeals("jack@infosys.com");
		Assert.assertNotNull(returned);
	}

	@Test
	public void getProductOnDealsInValid()throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerDealsService.NO_PRODUCT_ON_DEALS");
		when(sellerDealsDAO.getProductOnDeals("jack@infosys.com")).thenReturn(null);
		sellerDealsService.getProductOnDeals("jack@infosys.com");
		
	}
	
	
	@Test
	public void testremoveProductOnDeals()throws Exception{
		Mockito.when(sellerDealsDAO.removeProductOnDeals(Mockito.anyInt())).thenReturn(1);
		Assert.assertNotNull(sellerDealsService.removeProductOnDeals(501001));
	}
	
	@Test
	public void getProductNotOnDealsValid()throws Exception{
		List<Product> list = new ArrayList<Product>();
		Product pd = null;
		list.add(pd);
		when(sellerDealsDAO.getProductNotOnDeals("jack@infosys.com")).thenReturn(list);
		List<Product> returned=sellerDealsService.getProductNotOnDeals("jack@infosys.com");
		Assert.assertNotNull(returned);
	}
	
	@Test
	public void getProductNotOnDealsInValid()throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerDealsService.EVERY_PRODUCT_ON_DEALS");
		when(sellerDealsDAO.getProductNotOnDeals("jack@infosys.com")).thenReturn(null);
		sellerDealsService.getProductNotOnDeals("jack@infosys.com");
	}
}
