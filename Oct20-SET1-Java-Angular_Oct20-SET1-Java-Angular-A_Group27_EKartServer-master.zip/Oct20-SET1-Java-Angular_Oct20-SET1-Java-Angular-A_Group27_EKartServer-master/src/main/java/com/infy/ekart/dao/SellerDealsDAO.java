package com.infy.ekart.dao;

import java.util.List;

import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;

public interface SellerDealsDAO {

	public Integer addProductOnDeals(ProductOnDeals productOnDeals);
	
	public List<ProductOnDeals> getProductOnDeals(String emailId);
	
	public Integer removeProductOnDeals(Integer dealId);
	
	public List<Product> getProductNotOnDeals(String emailId);
	
}