package com.infy.ekart.api;

import java.util.List;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.ekart.model.Product;
import com.infy.ekart.model.ProductOnDeals;
import com.infy.ekart.service.SellerDealsService;

@CrossOrigin
@RestController
@RequestMapping("SellerDealsAPI")
public class SellerDealsAPI {
	@Autowired
	private SellerDealsService sellerDealsService;

	@Autowired
	private Environment environment;

	static Logger logger = LogManager.getLogger(SellerAPI.class.getName());

	@PostMapping(value = "addProductToSellerDeals")
	public ResponseEntity<?> addNewProductToSellerDeals(@RequestBody ProductOnDeals productOnDeals) throws Exception {
		try {

			logger.info("ADDING PRODUCT TO TODAY'S DEAL, PRODUCT ID: " + productOnDeals.getProduct().getProductId());

			Integer newDealId = sellerDealsService.addProductOnDeals(productOnDeals);

			logger.info("PRODUCT ADDED SUCCESSFULLY TO DEALS, PRODUCT ID: " + productOnDeals.getProduct().getProductId()
					+ " WITH DEAL ID: " + newDealId);

			String successMessage = environment.getProperty("SellerDealsAPI.PRODUCT_ADDED_SUCCESSFULLY") + newDealId;

			return new ResponseEntity<String>(successMessage, HttpStatus.OK);

		} catch (Exception e) {
			if (e.getMessage().contains("Validator")) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
			}
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}

	}
	@GetMapping(value="getProductOnDeals/{emailId:.+}")
	public ResponseEntity<List<ProductOnDeals>> getProductOnDeals(@PathVariable("emailId") String emailId) throws Exception{
		try {
			List<ProductOnDeals> productDeals=sellerDealsService.getProductOnDeals(emailId);
			return new ResponseEntity<List<ProductOnDeals>>(productDeals,HttpStatus.OK);
		}
		catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,environment.getProperty(e.getMessage()));

		}    
	}

	@PostMapping(value = "removeProductOnDeals")
	public ResponseEntity<String> removeProductOnDeals(@RequestBody ProductOnDeals productOnDeals) throws Exception{
		try {
			Integer productId = sellerDealsService.removeProductOnDeals(productOnDeals.getDealId());

			String message = environment.getProperty("SellerDealsAPI.PRODUCT_REMOVED_SUCCESSFULLY") + productId;

			return new ResponseEntity<String>(message, HttpStatus.OK);
		} catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
	}

	@GetMapping(value = "getProductNotOnDeals/{emailId:.+}")
	public ResponseEntity<List<Product>> getProductNotOnDeals(@PathVariable("emailId") String emailId) throws Exception{

		try {
			return new ResponseEntity<List<Product>>(sellerDealsService.getProductNotOnDeals(emailId), HttpStatus.OK);		

		} catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
	}

}